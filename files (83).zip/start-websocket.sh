#!/bin/bash
cd /var/www/vhosts/turnpage.io/httpdocs
php websocket/server.php