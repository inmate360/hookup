<?php
session_start();
header('Location: choose-location.php');
exit();
?>