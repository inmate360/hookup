<?php
session_start();
require_once 'config/database.php';
require_once 'classes/PrivateMessaging.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$pm = new PrivateMessaging($db);

$error = '';
$success = '';
$recipient_id = isset($_GET['to']) ? (int)$_GET['to'] : null;
$recipient_name = '';

// Get recipient info if specified
if($recipient_id) {
    $query = "SELECT username FROM users WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $recipient_id);
    $stmt->execute();
    $recipient = $stmt->fetch();
    $recipient_name = $recipient['username'] ?? '';
}

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $recipient_id = (int)$_POST['recipient_id'];
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    
    if(empty($recipient_id) || empty($subject) || empty($message)) {
        $error = 'All fields are required';
    } else {
        $attachment = !empty($_FILES['attachment']['tmp_name']) ? $_FILES['attachment'] : null;
        $result = $pm->createThread($_SESSION['user_id'], $recipient_id, $subject, $message, $attachment);
        
        if($result['success']) {
            header('Location: messages-view.php?thread=' . $result['thread_id'] . '&sent=1');
            exit();
        } else {
            $error = $result['error'];
        }
    }
}

include 'views/header.php';
?>

<!-- Tailwind CSS & Bootstrap -->
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
.user-search-result {
    cursor: pointer;
    transition: all 0.2s ease;
}
.user-search-result:hover {
    background: rgba(66, 103, 245, 0.1);
    transform: translateX(4px);
}
</style>

<div class="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-6">
    <div class="container mx-auto px-4" style="max-width: 900px;">
        
        <!-- Header -->
        <div class="card border-0 shadow-lg rounded-4 mb-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="h2 fw-bold mb-1">
                            <i class="bi bi-pencil-square me-2"></i> Compose Message
                        </h1>
                        <p class="mb-0 opacity-90">Send a private message</p>
                    </div>
                    <a href="messages-inbox.php" class="btn btn-light rounded-pill px-4">
                        <i class="bi bi-arrow-left me-2"></i> Back to Inbox
                    </a>
                </div>
            </div>
        </div>
        
        <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow mb-4" role="alert">
            <i class="bi bi-exclamation-triangle me-2"></i>
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Compose Form -->
        <div class="card border-0 shadow-lg rounded-4">
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data" id="composeForm">
                    
                    <!-- Recipient Selection -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-person me-2"></i> To:
                        </label>
                        <div class="position-relative">
                            <input type="text" 
                                   class="form-control form-control-lg" 
                                   id="recipientSearch"
                                   placeholder="Search for a user..."
                                   value="<?php echo htmlspecialchars($recipient_name); ?>"
                                   autocomplete="off">
                            <input type="hidden" name="recipient_id" id="recipientId" value="<?php echo $recipient_id ?: ''; ?>">
                            
                            <div id="searchResults" class="position-absolute w-100 mt-1 d-none" style="z-index: 1000;">
                                <div class="card border-0 shadow-lg">
                                    <div class="list-group list-group-flush" id="userResults">
                                        <!-- Search results will appear here -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <small class="text-muted">Start typing to search for users</small>
                    </div>
                    
                    <!-- Subject -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-chat-quote me-2"></i> Subject:
                        </label>
                        <input type="text" 
                               name="subject" 
                               class="form-control form-control-lg" 
                               placeholder="Enter message subject..."
                               required
                               maxlength="255">
                    </div>
                    
                    <!-- Message -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-card-text me-2"></i> Message:
                        </label>
                        <textarea name="message" 
                                  class="form-control form-control-lg" 
                                  rows="10"
                                  placeholder="Type your message here..."
                                  required></textarea>
                        <small class="text-muted">Be respectful and follow community guidelines</small>
                    </div>
                    
                    <!-- Attachment -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-paperclip me-2"></i> Attachment (Optional):
                        </label>
                        <input type="file" 
                               name="attachment" 
                               class="form-control form-control-lg"
                               accept="image/*,.pdf,.doc,.docx,.txt">
                        <small class="text-muted">Max file size: 5MB. Allowed: Images, PDF, DOC, TXT</small>
                    </div>
                    
                    <!-- Actions -->
                    <div class="d-flex gap-2 justify-content-end">
                        <button type="button" onclick="saveDraft()" class="btn btn-outline-secondary btn-lg rounded-pill px-4">
                            <i class="bi bi-save me-2"></i> Save Draft
                        </button>
                        <button type="submit" class="btn btn-primary btn-lg rounded-pill px-4">
                            <i class="bi bi-send me-2"></i> Send Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
let searchTimeout;
const recipientSearch = document.getElementById('recipientSearch');
const recipientId = document.getElementById('recipientId');
const searchResults = document.getElementById('searchResults');
const userResults = document.getElementById('userResults');

recipientSearch.addEventListener('input', function() {
    const query = this.value.trim();
    
    clearTimeout(searchTimeout);
    
    if(query.length < 2) {
        searchResults.classList.add('d-none');
        return;
    }
    
    searchTimeout = setTimeout(() => {
        searchUsers(query);
    }, 300);
});

function searchUsers(query) {
    fetch(`/api/search-users.php?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            if(data.success && data.users.length > 0) {
                displaySearchResults(data.users);
            } else {
                userResults.innerHTML = '<div class="list-group-item">No users found</div>';
                searchResults.classList.remove('d-none');
            }
        })
        .catch(error => {
            console.error('Search error:', error);
        });
}

function displaySearchResults(users) {
    userResults.innerHTML = '';
    
    users.forEach(user => {
        const item = document.createElement('div');
        item.className = 'list-group-item list-group-item-action user-search-result';
        item.innerHTML = `
            <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle bg-gradient-to-br from-blue-500 to-purple-600 d-flex align-items-center justify-content-center text-white fw-bold" 
                     style="width: 40px; height: 40px;">
                    ${user.username.charAt(0).toUpperCase()}
                </div>
                <div>
                    <div class="fw-semibold">${escapeHtml(user.username)}</div>
                    ${user.is_online ? '<small class="text-success"><i class="bi bi-circle-fill"></i> Online</small>' : ''}
                </div>
            </div>
        `;
        item.onclick = () => selectUser(user);
        userResults.appendChild(item);
    });
    
    searchResults.classList.remove('d-none');
}

function selectUser(user) {
    recipientSearch.value = user.username;
    recipientId.value = user.id;
    searchResults.classList.add('d-none');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Hide search results when clicking outside
document.addEventListener('click', function(e) {
    if(!recipientSearch.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.classList.add('d-none');
    }
});

function saveDraft() {
    const formData = new FormData(document.getElementById('composeForm'));
    formData.append('action', 'save_draft');
    
    fetch('/api/pm-drafts.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('Draft saved successfully!');
        } else {
            alert('Failed to save draft');
        }
    });
}
</script>

<?php include 'views/footer.php'; ?>