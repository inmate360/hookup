<?php
// Get unread messages count if user is logged in
$unread_messages = 0;
$unread_notifications = 0;
$incognito_active = false;
$user_location_set = false;
$current_theme = 'dark';

if(isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../classes/Message.php';
    require_once __DIR__ . '/../classes/SmartNotifications.php';
    require_once __DIR__ . '/../classes/IncognitoMode.php';
    
    $db_header = new Database();
    $conn_header = $db_header->getConnection();
    
    $msg_header = new Message($conn_header);
    $unread_messages = $msg_header->getTotalUnreadCount($_SESSION['user_id']);
    
    $notif_header = new SmartNotifications($conn_header);
    $unread_notifications = $notif_header->getUnreadCount($_SESSION['user_id']);
    
    $incognito_header = new IncognitoMode($conn_header);
    $incognito_active = $incognito_header->isActive($_SESSION['user_id']);
    
    // Check if user has location set and get theme
    $query = "SELECT current_latitude, auto_location, theme_preference FROM users WHERE id = :user_id LIMIT 1";
    $stmt = $conn_header->prepare($query);
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    $user_data = $stmt->fetch();
    
    if($user_data) {
        $user_location_set = !empty($user_data['current_latitude']);
        $current_theme = $user_data['theme_preference'] ?? 'dark';
    }
}

// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $current_theme; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <meta name="description" content="Turnpage - Local hookup classifieds. Post and browse personal ads in your area.">
    <meta name="theme-color" content="#4267F5">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Turnpage">
    <title>Turnpage - Local Hookup Classifieds</title>
    <link rel="stylesheet" href="/assets/css/dark-blue-theme.css">
    <link rel="stylesheet" href="/assets/css/light-theme.css">
    <link rel="stylesheet" href="/assets/css/bottom-nav.css">
    <meta name="format-detection" content="telephone=no">
    <link rel="icon" type="image/png" href="/logo.png">
    <link rel="apple-touch-icon" href="/logo.png">
</head>
<body class="<?php echo isset($_SESSION['user_id']) ? 'has-bottom-nav' : ''; ?>">
    <!-- Navigation -->
    <nav class="navbar-blue">
        <div class="container">
            <div class="nav-brand">
                <img src="/logo.png" alt="Turnpage" class="brand-logo">
                <a href="<?php echo isset($_SESSION['current_city']) ? '/city.php?location=' . $_SESSION['current_city'] : '/choose-location.php'; ?>">
                    Turnpage
                </a>
            </div>
            <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <div class="nav-menu" id="navMenu" role="navigation">
                <?php if(isset($_SESSION['user_id'])): ?>
                    
                    <a href="/nearby-users.php" class="<?php echo $current_page == 'nearby-users' ? 'active' : ''; ?>">
                        📍 Nearby
                        <?php if(!$user_location_set): ?>
                        <span class="notification-badge" style="background: var(--warning-orange);">!</span>
                        <?php endif; ?>
                    </a>
                    
                    <a href="/my-listings.php" class="<?php echo $current_page == 'my-listings' ? 'active' : ''; ?>">
                        📝 My Ads
                    </a>
                    
                    <a href="/messages-chat-simple.php" class="<?php echo $current_page == 'messages-chat-simple' ? 'active' : ''; ?>">
                        💬 Messages 
                        <?php if($unread_messages > 0): ?>
                            <span class="notification-badge"><?php echo $unread_messages; ?></span>
                        <?php endif; ?>
                    </a>
                    
                    <a href="/notifications.php" class="<?php echo $current_page == 'notifications' ? 'active' : ''; ?>">
                        🔔
                        <?php if($unread_notifications > 0): ?>
                            <span class="notification-badge"><?php echo $unread_notifications; ?></span>
                        <?php endif; ?>
                    </a>
                    
                    <a href="/profile.php?id=<?php echo $_SESSION['user_id']; ?>" class="<?php echo $current_page == 'profile' ? 'active' : ''; ?>">
                        👤 Profile
                    </a>
                    
                    <div class="nav-dropdown">
                        <a href="#" class="<?php echo in_array($current_page, ['settings', 'location-settings']) ? 'active' : ''; ?>">
                            ⚙️ Settings ▼
                        </a>
                        <div class="nav-dropdown-menu">
                            <a href="/settings.php">Account Settings</a>
                            <a href="/location-settings.php">📍 Location Settings</a>
                            <a href="/privacy-settings.php">🔒 Privacy</a>
                            <a href="/blocked-users.php">🚫 Blocked Users</a>
                            <a href="/connect-social.php">🔗 Social Media</a>
                        </div>
                    </div>
                    
                    <a href="/logout.php">Logout</a>
                <?php else: ?>
                    <a href="/about.php" class="<?php echo $current_page == 'about' ? 'active' : ''; ?>">About</a>
                    <a href="/how-it-works.php" class="<?php echo $current_page == 'how-it-works' ? 'active' : ''; ?>">How It Works</a>
                    <a href="/membership.php" class="<?php echo $current_page == 'membership' ? 'active' : ''; ?>">
                        💎 Premium
                    </a>
                    <a href="/login.php" class="<?php echo $current_page == 'login' ? 'active' : ''; ?>">
                        Login
                    </a>
                    <a href="/register.php" class="btn-primary btn-small">
                        Sign Up
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <?php if($incognito_active && isset($_SESSION['user_id'])): ?>
    <div class="incognito-indicator">
        🕶️ Incognito Mode Active
    </div>
    <?php endif; ?>
    
    <?php if(isset($_SESSION['user_id']) && !$user_location_set): ?>
    <div class="location-notice">
        <div class="container" style="display: flex; justify-content: space-between; align-items: center;">
            <span>📍 Enable location to discover nearby users and see who's close to you</span>
            <button class="btn-primary btn-small" onclick="enableLocationFromBanner()">
                Enable Location
            </button>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if(isset($_SESSION['user_id'])): ?>
    <!-- Bottom Navigation Bar (Mobile Only) -->
    <nav class="bottom-nav">
        <div class="bottom-nav-container">
            <a href="<?php echo isset($_SESSION['current_city']) ? '/city.php?location=' . $_SESSION['current_city'] : '/choose-location.php'; ?>" 
               class="bottom-nav-item <?php echo in_array($current_page, ['index', 'city', 'choose-location']) ? 'active' : ''; ?>">
                <div class="bottom-nav-icon">🏠</div>
                <span class="bottom-nav-label">Home</span>
            </a>
            
            <a href="/nearby-users.php" class="bottom-nav-item <?php echo $current_page == 'nearby-users' ? 'active' : ''; ?>">
                <div class="bottom-nav-icon">📍</div>
                <span class="bottom-nav-label">Nearby</span>
                <?php if(!$user_location_set): ?>
                <span class="bottom-nav-badge" style="background: var(--warning-orange);">!</span>
                <?php endif; ?>
            </a>
            
            <a href="/messages-chat-simple.php" class="bottom-nav-item <?php echo $current_page == 'messages-chat-simple' ? 'active' : ''; ?>">
                <div class="bottom-nav-icon">💬</div>
                <span class="bottom-nav-label">Messages</span>
                <?php if($unread_messages > 0): ?>
                <span class="bottom-nav-badge"><?php echo $unread_messages; ?></span>
                <?php endif; ?>
            </a>
            
            <a href="/my-listings.php" class="bottom-nav-item <?php echo $current_page == 'my-listings' ? 'active' : ''; ?>">
                <div class="bottom-nav-icon">📝</div>
                <span class="bottom-nav-label">My Posts</span>
            </a>
            
            <a href="/favorites.php" class="bottom-nav-item <?php echo $current_page == 'favorites' ? 'active' : ''; ?>">
                <div class="bottom-nav-icon">⭐</div>
                <span class="bottom-nav-label">Favorites</span>
            </a>
        </div>
    </nav>
    
    <!-- Theme Toggle (Modern Switch) -->
    <?php 
    // Pass the database connection to the theme toggle
    $db = $conn_header ?? null;
    include __DIR__ . '/../components/theme-toggle.php'; 
    ?>
    <?php endif; ?>
    
    <main>

<style>
.brand-logo {
    width: 32px;
    height: 32px;
    margin-right: 8px;
    vertical-align: middle;
    object-fit: contain;
}

.location-notice {
    background: linear-gradient(135deg, rgba(66, 103, 245, 0.95), rgba(29, 155, 240, 0.95));
    color: white;
    padding: 1rem 0;
    text-align: center;
    border-bottom: 2px solid var(--primary-blue);
}

.nav-dropdown {
    position: relative;
}

.nav-dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 8px;
    min-width: 200px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    z-index: 1000;
}

.nav-dropdown:hover .nav-dropdown-menu {
    display: block;
}

.nav-dropdown-menu a {
    display: block;
    padding: 0.75rem 1rem;
    color: var(--text-white);
    text-decoration: none;
    border-bottom: 1px solid var(--border-color);
}

.nav-dropdown-menu a:last-child {
    border-bottom: none;
}

.nav-dropdown-menu a:hover {
    background: rgba(66, 103, 245, 0.1);
    color: var(--primary-blue);
}

@media (max-width: 768px) {
    .brand-logo {
        width: 28px;
        height: 28px;
    }
    
    .location-notice {
        font-size: 0.9rem;
        padding: 0.75rem 0;
    }
    
    .location-notice .container {
        flex-direction: column;
        gap: 0.5rem;
    }
}
</style>

<script>
// Enable location from banner
function enableLocationFromBanner() {
    if(!navigator.geolocation) {
        alert('Geolocation is not supported by your browser');
        return;
    }
    
    const banner = document.querySelector('.location-notice');
    if(banner) {
        banner.innerHTML = '<div class="container">📍 Getting your location...</div>';
    }
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            updateLocationSilent(position.coords.latitude, position.coords.longitude, () => {
                if(banner) banner.style.display = 'none';
                location.reload();
            });
        },
        (error) => {
            console.error('Geolocation error:', error);
            alert('Unable to get your location. Please enable location access in your browser.');
            if(banner) {
                location.reload();
            }
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
}

// Update location silently
function updateLocationSilent(latitude, longitude, callback) {
    const formData = new FormData();
    formData.append('action', 'update_location');
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);
    formData.append('auto_detected', 'true');
    
    fetch('/api/location.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success && callback) {
            callback();
        }
    })
    .catch(error => {
        console.error('Error updating location:', error);
    });
}

// Mobile menu toggle
const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');

if(menuToggle && navMenu) {
    menuToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        this.classList.toggle('active');
        navMenu.classList.toggle('active');
        
        // Prevent body scroll when menu is open
        if(navMenu.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if(!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
            menuToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
    
    // Close menu when clicking a link
    navMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function() {
            menuToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });
}
</script>