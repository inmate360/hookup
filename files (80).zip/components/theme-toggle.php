<?php
// Get user's current theme
$current_theme = 'dark';
if(isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../classes/ThemeSwitcher.php';
    $themeSwitcher = new ThemeSwitcher($db);
    $current_theme = $themeSwitcher->getUserTheme($_SESSION['user_id']);
}
?>

<div class="theme-toggle" id="themeToggle">
    <button class="theme-toggle-btn" onclick="toggleTheme()" title="Toggle theme">
        <span class="theme-icon" id="themeIcon">
            <?php if($current_theme === 'light'): ?>
                🌙
            <?php else: ?>
                ☀️
            <?php endif; ?>
        </span>
    </button>
</div>

<style>
.theme-toggle {
    position: fixed;
    bottom: 100px;
    right: 20px;
    z-index: 999;
}

.theme-toggle-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    transition: all 0.3s;
}

.theme-toggle-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4);
}

.theme-icon {
    font-size: 1.5rem;
}

@media (max-width: 768px) {
    .theme-toggle {
        bottom: 90px;
        right: 15px;
    }
    
    .theme-toggle-btn {
        width: 45px;
        height: 45px;
    }
}
</style>

<script>
// Initialize theme on page load
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = '<?php echo $current_theme; ?>';
    applyTheme(savedTheme);
});

function toggleTheme() {
    const root = document.documentElement;
    const currentTheme = root.getAttribute('data-theme') || 'dark';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    applyTheme(newTheme);
    
    // Save to server
    <?php if(isset($_SESSION['user_id'])): ?>
    saveThemePreference(newTheme);
    <?php else: ?>
    // Save to localStorage for non-logged-in users
    localStorage.setItem('theme', newTheme);
    <?php endif; ?>
}

function applyTheme(theme) {
    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    
    const icon = document.getElementById('themeIcon');
    if(icon) {
        icon.textContent = theme === 'light' ? '🌙' : '☀️';
    }
}

<?php if(isset($_SESSION['user_id'])): ?>
function saveThemePreference(theme) {
    fetch('/api/theme.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=update_theme&theme=' + theme
    })
    .then(response => response.json())
    .then(data => {
        if(!data.success) {
            console.error('Failed to save theme preference');
        }
    })
    .catch(error => {
        console.error('Error saving theme:', error);
    });
}
<?php endif; ?>
</script>